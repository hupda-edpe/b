package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractD1Impl extends AbstractConnector {

	protected final String TEST1_OUTPUT_PARAMETER = "test1";

	protected final void setTest1(javax.xml.transform.Source test1) {
		setOutputParameter(TEST1_OUTPUT_PARAMETER, test1);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {

	}

}
