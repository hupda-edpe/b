package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractReactOnEventImpl extends AbstractConnector {

	protected final static String UBMURL_INPUT_PARAMETER = "ubmURL";
	protected final static String QUERYPARAMETER_INPUT_PARAMETER = "queryParameter";
	protected final static String USEMOSTRECENT_INPUT_PARAMETER = "useMostRecent";
	protected final static String POLLINGINTERVALL_INPUT_PARAMETER = "pollingIntervall";
	protected final static String USEBASICAUTH_INPUT_PARAMETER = "useBasicAuth";
	protected final static String USERNAME_INPUT_PARAMETER = "username";
	protected final static String PASSWORD_INPUT_PARAMETER = "password";
	protected final String OUTPUT1_OUTPUT_PARAMETER = "output1";

	protected final java.lang.String getUbmURL() {
		return (java.lang.String) getInputParameter(UBMURL_INPUT_PARAMETER);
	}

	protected final java.util.List<java.util.List> getQueryParameter() {
		return (java.util.List<java.util.List>) getInputParameter(QUERYPARAMETER_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getUseMostRecent() {
		return (java.lang.Boolean) getInputParameter(USEMOSTRECENT_INPUT_PARAMETER);
	}

	protected final java.lang.Integer getPollingIntervall() {
		return (java.lang.Integer) getInputParameter(POLLINGINTERVALL_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getUseBasicAuth() {
		return (java.lang.Boolean) getInputParameter(USEBASICAUTH_INPUT_PARAMETER);
	}

	protected final java.lang.String getUsername() {
		return (java.lang.String) getInputParameter(USERNAME_INPUT_PARAMETER);
	}

	protected final java.lang.String getPassword() {
		return (java.lang.String) getInputParameter(PASSWORD_INPUT_PARAMETER);
	}

	protected final void setOutput1(java.lang.String output1) {
		setOutputParameter(OUTPUT1_OUTPUT_PARAMETER, output1);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getUbmURL();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("ubmURL type is invalid");
		}
		try {
			getQueryParameter();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"queryParameter type is invalid");
		}
		try {
			getUseMostRecent();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"useMostRecent type is invalid");
		}
		try {
			getPollingIntervall();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"pollingIntervall type is invalid");
		}
		try {
			getUseBasicAuth();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"useBasicAuth type is invalid");
		}
		try {
			getUsername();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("username type is invalid");
		}
		try {
			getPassword();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("password type is invalid");
		}

	}

}
