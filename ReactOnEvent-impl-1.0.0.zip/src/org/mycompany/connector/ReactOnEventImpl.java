/**
 * Connector that polls notifications from UBM
 * created with Bonita BPM 7.2.3 Community edition
 */
package org.mycompany.connector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.bonitasoft.engine.connector.ConnectorException;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class ReactOnEventImpl extends AbstractReactOnEventImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		//getUbmURL();
		//getQueryParameter();
		//getUseMostRecent();
		//getRetryDuration();
		//getPollingIntervall();
		//getUseBasicAuth();
		//getUsername();
		//getPassword();
			

		// TODO read bitronix.tm.timer.defaultTransactionTimeout (from version 7.4 stored in DB)
		// Connector must be finished after x seconds defined by bitronix.tm.timer.defaultTransactionTimeout
		// reduce TransactionTimeout by 3 seconds as the initialization and output of the connector could take some time
		long startTime = System.currentTimeMillis();
		int transactionTimeout = 60-3;

		
		// Build HTTP URL String 
		String url = getUbmURL();
		url += "/api/search?";
		
		// initialize output
		setOutput1("failed");
		
		// process query parameter
		for (int i = 0; i < getQueryParameter().size(); i++) {
			if ((getQueryParameter().get(i).get(0).toString().length() > 0) && (getQueryParameter().get(i).get(1).toString().length() > 0)) {
				
				// handle comparators
				url += "&" + getQueryParameter().get(i).get(0).toString() + "=";
				if (getQueryParameter().get(i).get(1).toString().charAt(0) == '<') {
					url += "%3C" + getQueryParameter().get(i).get(1).toString().substring(1);
				}
				else if (getQueryParameter().get(i).get(1).toString().charAt(0) == '>') {
					url += "%3E" + getQueryParameter().get(i).get(1).toString().substring(1);
				}
				else url += getQueryParameter().get(i).get(1).toString();
			}
		}
		
		// add sort parameter to GET-URL
		if (getUseMostRecent() == true)	url += "&ubmsort=desc";	
		else url += "&ubmsort=asc";
		// make URL final to be able to use it below
		final String finalUrl = url;

		// poll data 
		final RequestConfig params = RequestConfig.custom().setConnectTimeout(3000).setSocketTimeout(3000).build();
    	String getResult = "";

    	    //perform DB poll
			// Handle case: BasicAuth enabled
	    	if(getUseBasicAuth() == true) {
				HttpGet httpGet = new HttpGet(finalUrl);
				httpGet.setConfig(params);
			    String auth = getUsername() + ":" + getPassword();
			    byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("ISO-8859-1")));
			    String authHeader = "Basic " + new String(encodedAuth);
			    httpGet.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
			    CloseableHttpClient client = HttpClientBuilder.create().build();
			    
			 // Get Data from UBM
			    try {				    
					CloseableHttpResponse response = client.execute(httpGet);
					assert response.getStatusLine().getStatusCode() == 200;
					
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity().getContent()));
					StringBuffer result = new StringBuffer();
					String line = "";
					while ((line = rd.readLine()) != null) {
						result.append(line);
					}
					getResult = result.toString();
					rd.close();
					response.close();
				    client.close();

				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			// Handle case: BasicAuth disabled
	    	else {
				HttpGet httpGet = new HttpGet(finalUrl);
				httpGet.setConfig(params);
				CloseableHttpClient client = HttpClients.createDefault();

				// Get Data from UBM
				try {				    
					CloseableHttpResponse response = client.execute(httpGet);
					assert response.getStatusLine().getStatusCode() == 200;
					
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity().getContent()));
					StringBuffer result = new StringBuffer();
					String line = "";
					while ((line = rd.readLine()) != null) {
						result.append(line);
					}
					getResult = result.toString();
					rd.close();
					response.close();
				    client.close();

				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				    
			}
			
			// IF notification was found set first element as output 
			JSONArray jArray = new JSONArray(getResult);						// if polling was successful
			if(jArray.length() > 0){
				JSONObject jObject = jArray.getJSONObject(0);
			    setOutput1(jObject.toString());
			    

				// Delete consumed notification
				final String delteUrl =  getUbmURL()+"/api/delete/"+jObject.getString("_id");
				final RequestConfig paramsDelete = RequestConfig.custom().setConnectTimeout(500).setSocketTimeout(500).build();
				
				// Handle case: BasicAuth enabled
				if(getUseBasicAuth() == true) {
					HttpDelete httpDelete = new HttpDelete(delteUrl);
					httpDelete.setConfig(paramsDelete);
				    String auth = getUsername() + ":" + getPassword();
				    byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("ISO-8859-1")));
				    String authHeader = "Basic " + new String(encodedAuth);
				    httpDelete.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
				    CloseableHttpClient clientDelete = HttpClientBuilder.create().build();
				    try {				    
						CloseableHttpResponse responseDelete = clientDelete.execute(httpDelete);
						assert responseDelete.getStatusLine().getStatusCode() == 200;
						responseDelete.close();
					    clientDelete.close();

					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} 
				// Handle case: BasicAuth disabled
				else {
					HttpDelete httpDelete = new HttpDelete(delteUrl);
					httpDelete.setConfig(paramsDelete);
				    CloseableHttpClient clientDelete = HttpClients.createDefault();
				    try {				    
						CloseableHttpResponse responseDelete = clientDelete.execute(httpDelete);
						assert responseDelete.getStatusLine().getStatusCode() == 200;
						responseDelete.close();
					    clientDelete.close();

					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			// if no results were found...
			else {
				// wait for PollingIntervall < transactionTimeout (must not exceed transactionTimeout)
				long sleepLimit = transactionTimeout*1000 - ((new Date()).getTime() - startTime);
				long sleepDuration;
				if (getPollingIntervall()*1000 > sleepLimit) sleepDuration = sleepLimit;
				else sleepDuration = Math.max(0,((getPollingIntervall()*1000)-((new Date()).getTime() - startTime)));
				try {
				    Thread.sleep(sleepDuration);
				} catch(InterruptedException e) {
				    Thread.currentThread().interrupt();
				}
			}
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}

}
